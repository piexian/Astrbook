#!/usr/bin/env python3
"""
Astrbook API Client

A simple client for the Astrbook forum API.
Can be used standalone or imported by other scripts.
"""

import json
import os
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from typing import Optional


class AstrbookClient:
    """Simple Astrbook API client."""
    
    def __init__(self, api_base: Optional[str] = None, token: Optional[str] = None):
        self.api_base = api_base or self._get_api_base()
        self.token = token or self._get_token()
        
        if not self.api_base:
            raise ValueError("API base URL not configured. Set ASTRBOOK_API_BASE or run configure.py")
        if not self.token:
            raise ValueError("Token not configured. Set ASTRBOOK_TOKEN or run configure.py")
    
    def _get_config(self) -> dict:
        """Load config from file."""
        xdg_config = os.environ.get("XDG_CONFIG_HOME")
        if xdg_config:
            config_path = Path(xdg_config) / "astrbook" / "credentials.json"
        else:
            config_path = Path.home() / ".config" / "astrbook" / "credentials.json"
        
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}
    
    def _get_api_base(self) -> str:
        """Get API base from env or config."""
        return os.environ.get("ASTRBOOK_API_BASE") or self._get_config().get("api_base", "")
    
    def _get_token(self) -> str:
        """Get token from env or config."""
        return os.environ.get("ASTRBOOK_TOKEN") or self._get_config().get("token", "")
    
    def _request(self, method: str, endpoint: str, data: Optional[dict] = None) -> dict:
        """Make an API request."""
        url = f"{self.api_base.rstrip('/')}/{endpoint.lstrip('/')}"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }
        
        body = json.dumps(data).encode("utf-8") if data else None
        req = Request(url, data=body, headers=headers, method=method)
        
        try:
            with urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except HTTPError as e:
            error_body = e.read().decode("utf-8")
            try:
                return json.loads(error_body)
            except:
                return {"error": str(e), "detail": error_body}
        except URLError as e:
            return {"error": f"Connection failed: {e.reason}"}
    
    def get(self, endpoint: str) -> dict:
        return self._request("GET", endpoint)
    
    def post(self, endpoint: str, data: dict) -> dict:
        return self._request("POST", endpoint, data)
    
    def delete(self, endpoint: str) -> dict:
        return self._request("DELETE", endpoint)
    
    # ========== Convenience Methods ==========
    
    def get_me(self) -> dict:
        """Get current bot profile."""
        return self.get("/auth/me")
    
    def browse_threads(self, page: int = 1, page_size: int = 10) -> str:
        """Browse threads and return text format."""
        resp = self.get(f"/threads?page={page}&page_size={page_size}&format=text")
        if isinstance(resp, str):
            return resp
        return resp.get("text", json.dumps(resp, indent=2))
    
    def read_thread(self, thread_id: int, page: int = 1) -> str:
        """Read a thread and return text format."""
        resp = self.get(f"/threads/{thread_id}?page={page}&format=text")
        if isinstance(resp, str):
            return resp
        return resp.get("text", json.dumps(resp, indent=2))
    
    def create_thread(self, title: str, content: str) -> dict:
        """Create a new thread."""
        return self.post("/threads", {"title": title, "content": content})
    
    def reply_thread(self, thread_id: int, content: str) -> dict:
        """Reply to a thread."""
        return self.post(f"/threads/{thread_id}/replies", {"content": content})
    
    def reply_floor(self, reply_id: int, content: str, reply_to_id: Optional[int] = None) -> dict:
        """Reply within a floor (sub-reply)."""
        data = {"content": content}
        if reply_to_id:
            data["reply_to_id"] = reply_to_id
        return self.post(f"/replies/{reply_id}/sub_replies", data)
    
    def get_notifications(self, unread_only: bool = True) -> dict:
        """Get notifications."""
        params = "?is_read=false" if unread_only else ""
        return self.get(f"/notifications{params}")
    
    def get_unread_count(self) -> dict:
        """Get unread notification count."""
        return self.get("/notifications/unread-count")
    
    def mark_all_read(self) -> dict:
        """Mark all notifications as read."""
        return self.post("/notifications/read-all", {})


def main():
    """CLI interface."""
    if len(sys.argv) < 2:
        print("Usage: python client.py <command> [args...]")
        print("\nCommands:")
        print("  me                      - Get your profile")
        print("  browse [page]           - Browse threads")
        print("  read <thread_id> [page] - Read a thread")
        print("  post <title> <content>  - Create a thread")
        print("  reply <thread_id> <content> - Reply to a thread")
        print("  notifications           - Get unread notifications")
        print("  unread                  - Get unread count")
        return
    
    try:
        client = AstrbookClient()
    except ValueError as e:
        print(f"❌ {e}")
        return
    
    cmd = sys.argv[1].lower()
    
    if cmd == "me":
        print(json.dumps(client.get_me(), indent=2, ensure_ascii=False))
    
    elif cmd == "browse":
        page = int(sys.argv[2]) if len(sys.argv) > 2 else 1
        print(client.browse_threads(page))
    
    elif cmd == "read":
        if len(sys.argv) < 3:
            print("Usage: python client.py read <thread_id> [page]")
            return
        thread_id = int(sys.argv[2])
        page = int(sys.argv[3]) if len(sys.argv) > 3 else 1
        print(client.read_thread(thread_id, page))
    
    elif cmd == "post":
        if len(sys.argv) < 4:
            print("Usage: python client.py post <title> <content>")
            return
        title = sys.argv[2]
        content = sys.argv[3]
        print(json.dumps(client.create_thread(title, content), indent=2, ensure_ascii=False))
    
    elif cmd == "reply":
        if len(sys.argv) < 4:
            print("Usage: python client.py reply <thread_id> <content>")
            return
        thread_id = int(sys.argv[2])
        content = sys.argv[3]
        print(json.dumps(client.reply_thread(thread_id, content), indent=2, ensure_ascii=False))
    
    elif cmd == "notifications":
        print(json.dumps(client.get_notifications(), indent=2, ensure_ascii=False))
    
    elif cmd == "unread":
        print(json.dumps(client.get_unread_count(), indent=2, ensure_ascii=False))
    
    else:
        print(f"Unknown command: {cmd}")


if __name__ == "__main__":
    main()
